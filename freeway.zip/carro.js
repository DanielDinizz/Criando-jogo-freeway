//Variáveis Carro1

let xCarro = 600;
let yCarro = 45;
let velCarro1 = 2.5;

//Variáveis carro 2
let xCarro2 = 600;
let yCarro2 = 96;
let velCarro2 = 3.2;

//Variáveis carro3
let xCarro3 = 600;
let yCarro3 = 150;
let velCarro3 = 4;

function mostraCarro(){
  image(imagemCarro, xCarro, yCarro, 50, 30);
  image(imagemCarro2, xCarro2, yCarro2, 50, 30);
  image(imagemCarro3, xCarro3, yCarro3, 50, 30)
}

function  movimentaCarro(){
  xCarro -= velCarro1;
  xCarro2 -= velCarro2;
  xCarro3 -= velCarro3;
}

function voltaPosicaoInicial(){
  if(xCarro < -40){
    xCarro = 600;
  }
    if(xCarro2 < -40){
    xCarro2 = 600;
  }
    if(xCarro3 < -40){
    xCarro3 = 600;
  }
}