//Variáveis Ator

let xVaca = 100;
let yVaca = 370;

function mostraAtor(){
  image(imagemDoAtor, xVaca, yVaca, 30, 25);
}

function movimentoVaca(){
  if(keyIsDown(UP_ARROW)){
    yVaca -= 3
  }
  if(keyIsDown(DOWN_ARROW)){
    yVaca += 3
  }
}